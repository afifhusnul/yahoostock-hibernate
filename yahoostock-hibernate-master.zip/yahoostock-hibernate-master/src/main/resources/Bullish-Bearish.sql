/**
 * Author:  NUSNAFIF
 * Created: Mar 6, 2016
 */

/*------------------- Strong Uptrend -------------------------
* Always Up for Last 5 Days
*/
SET @date = '2016.03.04'; /* Please change this date accordingly, but need to input on Friday-Date*/

SELECT A.ID_TICKLER, A.DT_TRX, MA1 AS 'LAST_PRICE-MA1', MA2,MA3,MA4,MA5
FROM (
SELECT ID_TICKLER, DT_TRX, OPEN_PRC, CLOSE_PRC AS MA1 FROM stock_trx
WHERE dt_trx = @date
and close_prc > open_prc
) A
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA2 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 1 DAY)
and close_prc > open_prc
) B
ON A.id_tickler = b.id_tickler
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA3 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 2 DAY)
and close_prc > open_prc
) C
ON A.id_tickler = C.id_tickler
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA4 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 3 DAY)
and close_prc > open_prc
) D
ON A.id_tickler = D.id_tickler
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA5 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 4 DAY)
and close_prc > open_prc
) E
ON A.id_tickler = E.id_tickler
WHERE
A.MA1 > B.MA2
AND B.MA2 >C.MA3


/*------------------- Bearish reverseal -------------------------
* Last price > ma1 <ma2 < ma3 < ma4 < ma5
*/
/*------------ TREND MENGUAT MA0 > MA5 ----------------------*/
SET @date = '2016.02.26'; /* Please change this date accordingly*/

SELECT A.ID_TICKLER, A.DT_TRX, MA1 AS 'LAST_PRICE-MA1', MA2,MA3,MA4,MA5
FROM (
SELECT ID_TICKLER, DT_TRX, OPEN_PRC, CLOSE_PRC AS MA1 FROM stock_trx
WHERE dt_trx = @date
and close_prc > open_prc
) A
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA2 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 1 DAY)
and close_prc < open_prc
) B
ON A.id_tickler = b.id_tickler
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA3 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 2 DAY)
and close_prc < open_prc
) C
ON A.id_tickler = C.id_tickler
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA4 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 3 DAY)
and close_prc < open_prc
) D
ON A.id_tickler = D.id_tickler
JOIN (
SELECT id_tickler, dt_trx, open_prc,close_prc as MA5 FROM stock_trx 
WHERE dt_trx = DATE_SUB(@date, INTERVAL 4 DAY)
and close_prc < open_prc
) E
ON A.id_tickler = E.id_tickler
